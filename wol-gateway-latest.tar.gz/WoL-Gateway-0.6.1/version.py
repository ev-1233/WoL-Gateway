"""
Version information for WOL Gateway
"""

__version__ = "0.6.1"
__github_repo__ = "ev-1233/wol-gateway"  # Update with your GitHub repo
